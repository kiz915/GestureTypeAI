# 🐙 GitHub Setup Guide for GestureType AI

Follow these steps to upload your project to GitHub.

---

## Step 1: Create GitHub Repository

1. Go to github.com and sign in
2. Click the **"+"** button (top right) → **"New repository"**
3. Repository name: `GestureTypeAI`
4. Description: `AI hand gesture system for typing, sign language and PC control`
5. Set to **Public**
6. ✅ Check "Add a README file"
7. Click **"Create repository"**

---

## Step 2: Upload Files

### Method A: Drag and Drop (Easiest)
1. Open your GitHub repository
2. Click **"Add file"** → **"Upload files"**
3. Drag all your project files and folders
4. Click **"Commit changes"**

### Method B: GitHub Desktop App
1. Download GitHub Desktop from desktop.github.com
2. Sign in with your GitHub account
3. Clone your repository
4. Copy project files into the folder
5. Commit and Push

### Method C: Google Colab (If using Colab)
Run this in a Colab cell:
```python
# Setup git in Colab
!git config --global user.email "your@email.com"
!git config --global user.name "Kishore"

# Clone your repo
!git clone https://github.com/YOUR_USERNAME/GestureTypeAI.git
%cd GestureTypeAI

# Copy your files here, then:
!git add .
!git commit -m "Add GestureType AI project"
!git push
```

---

## Step 3: Make Your Repository Look Professional

### Add these to your README.md:
- A demo GIF or screenshot of your project working
- Badges (shields.io)
- Clear installation instructions
- Your name and contact

### Add Topics to your repo:
Go to your repo → Click ⚙️ gear icon next to "About"
Add topics: `python`, `computer-vision`, `mediapipe`, `opencv`, `gesture-recognition`, `sign-language`, `streamlit`, `ai`, `machine-learning`

---

## Step 4: Deploy on Streamlit Cloud (Free!)

1. Go to share.streamlit.io
2. Sign in with GitHub
3. Click **"New app"**
4. Select your `GestureTypeAI` repository
5. Main file: `app.py`
6. Click **"Deploy"**

Your app will be live at: `https://YOUR_USERNAME-gesturetypeai.streamlit.app`

---

## Step 5: Add to Your Resume

```
Projects:
GestureType AI | Python, OpenCV, MediaPipe, Streamlit
• Built a real-time hand gesture recognition system using computer vision
• Implemented A-Z letter typing, ASL sign language detection, and PC control
• Deployed as a live web application on Streamlit Cloud
• GitHub: github.com/YOUR_USERNAME/GestureTypeAI
```

---

## Step 6: Apply for Internships

Use this project link in applications on:
- **Internshala** (internshala.com)
- **Forage** (theforage.com) — virtual internships
- **LinkedIn** — add to Projects section
- **LetsIntern**

---

🎉 Congratulations Kishore! Your project is now live and portfolio-ready!
